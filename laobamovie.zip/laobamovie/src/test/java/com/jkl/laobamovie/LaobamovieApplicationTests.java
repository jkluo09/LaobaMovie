package com.jkl.laobamovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaobamovieApplicationTests {

    @Test
    void contextLoads() {
    }

}
