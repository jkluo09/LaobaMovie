package com.jkl.laobamovie.Recommend;


import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.spark_project.guava.collect.Lists;

import java.util.function.Function;

public class JavaSpark {



    System.("hadoop.home.dir","D:\\bishe\\hadoop-2.7.1")


    SparkConf conf = new SparkConf().setMaster("local").setAppName("TestSpark");
    JavaSparkContext sc = new JavaSparkContext(conf);


    JavaRDD<Integer> intRDD = sc.parallelize(Lists.newArrayList(1,2,3,4,5));

    JavaRDD<Integer> relRDD = intRDD.map(new Function<Integer, Integer>() {
        public Integer call(Integer integer) throws Exception {
            return integer+10;
        }
    });
    relRDD.foreach(new VoidFunction<Integer>() {
        public void call(Integer integer) throws Exception {
            System.out.println("relRDD---->:"+integer);
        }
}
